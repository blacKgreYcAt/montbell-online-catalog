# 5 月架構改版實作代碼

**目標**：改版網站架構，準備 6 月翻譯
**內容**：只做架構，跳過所有翻譯邏輯
**時間**：7-10 小時
**成本**：$0（無 API 消耗）

---

## 第 1 步：目錄結構設置（1 小時）

### 1.1 建立目錄

```bash
# 從專案根目錄執行
mkdir -p data/scraping_checkpoints
mkdir -p data/backups
mkdir -p data/scraping_logs
mkdir -p data/temp

# 確認結構
tree data/

# 預期輸出：
# data/
# ├── backups/
# ├── scraping_checkpoints/
# ├── scraping_logs/
# └── temp/
```

### 1.2 更新 `.gitignore`

```gitignore
# 系統檔案
.DS_Store
Thumbs.db
*.log

# Node 模組
node_modules/
.npm
package-lock.json

# Vercel
.vercel
.env.local
.env.*.local

# Next.js
.next/
out/
dist/

# IDE
.vscode/
.idea/
*.swp
*.swo

# 只忽略臨時檔案，但保留 checkpoint 和備份
data/temp/
data/*.tmp

# ✅ 不要忽略：
# data/scraping_checkpoints/
# data/backups/
# data/scraping_logs/
```

### 1.3 提交到 Git

```bash
# 建立 .gitkeep 以確保目錄被追蹤
touch data/scraping_checkpoints/.gitkeep
touch data/backups/.gitkeep
touch data/scraping_logs/.gitkeep

# 提交
git add data/
git commit -m "feat: 新增 checkpoint 和備份目錄結構"
git push origin main
```

---

## 第 2 步：預留資料結構（30 分鐘）

### 2.1 `public/translationMeta.json`（預留，無內容）

```json
{
  "version": "1.0.0",
  "lastUpdated": null,
  "updatedBy": null,
  "description": "等待 6 月翻譯",
  "stats": {
    "totalProducts": 0,
    "translatedProducts": 0,
    "pendingProducts": 0,
    "translationCompletionRate": 0
  },
  "products": {}
}
```

### 2.2 `public/translationStatus.json`（預留）

```json
{
  "generatedAt": null,
  "summary": {
    "totalProducts": 0,
    "completed": 0,
    "pending": 0,
    "completionPercentage": 0,
    "estimatedCompletionDate": null,
    "status": "等待 6 月翻譯"
  },
  "byCategory": {},
  "qualityMetrics": {
    "averageQuality": 0,
    "excellentCount": 0,
    "goodCount": 0,
    "fairCount": 0,
    "poorCount": 0
  },
  "pendingProducts": []
}
```

### 2.3 `public/versionHistory.json`（預留）

```json
{
  "versions": [],
  "currentVersion": "1.0.0",
  "message": "等待 6 月翻譯開始"
}
```

### 2.4 `public/robots.txt`（安全）

```
# Montbell Taiwan 線上目錄

# 阻止爬蟲訪問 checkpoint 和備份檔案
User-agent: *
Disallow: /scraping_checkpoints/
Disallow: /translationMeta.json
Disallow: /admin/

# 允許主要搜尋引擎
User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /
```

---

## 第 3 步：新增 API 端點（2-3 小時）

### 3.1 `src/app/api/upload-excel/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import fs from 'fs/promises';
import path from 'path';

interface ProductRow {
  sku: string;
  name: string;
  color: string;
  size: string;
  description: string;
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: '請提供 Excel 檔案' },
        { status: 400 }
      );
    }

    // 驗證檔案類型
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      return NextResponse.json(
        { error: '只支持 .xlsx 或 .xls 檔案' },
        { status: 400 }
      );
    }

    // 讀取 Excel
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    
    // 轉換為 JSON
    const data = XLSX.utils.sheet_to_json(worksheet) as any[];

    // 驗證和轉換資料
    const products: ProductRow[] = data.map((row: any) => ({
      sku: String(row.SKU || row.sku || '').trim(),
      name: String(row.名稱 || row.名称 || row.Name || '').trim(),
      color: String(row.顏色 || row.颜色 || row.Color || '').trim(),
      size: String(row.尺寸 || row.Size || '').trim(),
      description: String(row.說明 || row.说明 || row.Description || '').trim()
    })).filter(p => p.sku); // 過濾掉無 SKU 的行

    // 驗證資料
    if (products.length === 0) {
      return NextResponse.json(
        { error: '未找到有效的商品資料（需要 SKU 欄位）' },
        { status: 400 }
      );
    }

    // 儲存到 public/products.json（先覆蓋，6 月改成 merge）
    const productsPath = path.join(process.cwd(), 'public/products.json');
    const productsData = {
      timestamp: new Date().toISOString(),
      totalCount: products.length,
      uploadedBy: 'Excel Upload',
      products: products.map(p => ({
        sku: p.sku,
        name: p.name,
        color: p.color,
        size: p.size,
        description: p.description,
        // 6 月才會有這些欄位
        imageUrl: null,
        englishDescription: null,
        chineseTranslation: null,
        translationStatus: 'pending',
        translationQuality: null
      }))
    };

    await fs.writeFile(
      productsPath,
      JSON.stringify(productsData, null, 2),
      'utf-8'
    );

    // 記錄日誌
    const logPath = path.join(
      process.cwd(),
      `data/scraping_logs/upload_${Date.now()}.log`
    );
    const logContent = `
上傳時間：${new Date().toISOString()}
檔案名稱：${file.name}
商品數量：${products.length}
上傳者：用戶
狀態：✅ 成功

上傳的商品列表：
${products.map(p => `- ${p.sku}: ${p.name} (${p.color}, ${p.size})`).join('\n')}

下一步：
等待 6 月執行翻譯和圖片爬蟲
`;

    await fs.writeFile(logPath, logContent, 'utf-8');

    return NextResponse.json({
      success: true,
      message: `成功上傳 ${products.length} 個商品`,
      productsCount: products.length,
      status: 'awaiting_translation',
      nextStep: '等待 6 月進行翻譯和圖片爬蟲',
      uploadTime: new Date().toISOString()
    });

  } catch (error) {
    console.error('Excel 上傳失敗:', error);
    return NextResponse.json(
      { 
        error: '上傳失敗',
        details: error instanceof Error ? error.message : '未知錯誤'
      },
      { status: 500 }
    );
  }
}
```

### 3.2 `src/app/api/translation-status/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET(request: NextRequest) {
  try {
    // 嘗試讀取 products.json
    let productsCount = 0;
    try {
      const productsPath = path.join(process.cwd(), 'public/products.json');
      const content = await fs.readFile(productsPath, 'utf-8');
      const data = JSON.parse(content);
      productsCount = data.products?.length || data.totalCount || 0;
    } catch {
      productsCount = 0;
    }

    // 返回狀態（目前都是 0，因為還沒翻譯）
    return NextResponse.json({
      timestamp: new Date().toISOString(),
      status: 'pending_translation',
      message: '等待 6 月翻譯開始',
      stats: {
        totalProducts: productsCount,
        translatedProducts: 0,
        pendingProducts: productsCount,
        completionRate: 0,
        estimatedCompletionDate: '2024-06-15'
      },
      timeline: {
        uploadDate: '2024-05-15',
        translationStartDate: '2024-06-01',
        targetCompletionDate: '2024-06-30'
      },
      nextAction: {
        description: '等待 6 月商品資料確認後開始翻譯',
        expectedDate: '2024-06-01'
      }
    });

  } catch (error) {
    console.error('查詢失敗:', error);
    return NextResponse.json(
      { error: '查詢失敗' },
      { status: 500 }
    );
  }
}
```

### 3.3 `src/app/api/version-history/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export async function GET(request: NextRequest) {
  try {
    const historyPath = path.join(process.cwd(), 'public/versionHistory.json');
    
    let history = {
      versions: [],
      currentVersion: '1.0.0',
      message: '等待 6 月翻譯開始'
    };

    try {
      const content = await fs.readFile(historyPath, 'utf-8');
      history = JSON.parse(content);
    } catch {
      // 檔案不存在，使用預設值
    }

    return NextResponse.json(history);

  } catch (error) {
    console.error('查詢版本歷史失敗:', error);
    return NextResponse.json(
      { error: '查詢失敗' },
      { status: 500 }
    );
  }
}
```

---

## 第 4 步：新增管理頁面（3-4 小時）

### 4.1 `src/app/admin/upload/page.tsx`

```typescript
'use client';

import { useState } from 'react';

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] || null);
    setError(null);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      setError('請選擇 Excel 檔案');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload-excel', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '上傳失敗');
      }

      setResult(data);
      setFile(null);

    } catch (err) {
      setError(err instanceof Error ? err.message : '上傳失敗');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">上傳商品清單</h1>

      <div className="bg-blue-50 p-4 rounded-lg mb-6">
        <p className="text-sm text-blue-800">
          📅 <strong>目前狀態：5 月架構改版</strong>
        </p>
        <p className="text-sm text-blue-800 mt-2">
          上傳 Excel 後，系統將在 6 月開始翻譯和圖片爬蟲。
        </p>
        <p className="text-sm text-blue-800 mt-2">
          Excel 需要包含：SKU、名稱、顏色、尺寸、基本說明
        </p>
      </div>

      <form onSubmit={handleUpload} className="border rounded-lg p-6">
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">
            選擇 Excel 檔案
          </label>
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileChange}
            disabled={uploading}
            className="w-full p-2 border rounded"
          />
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded">
            {error}
          </div>
        )}

        {result && (
          <div className="mb-6 p-4 bg-green-50 text-green-700 rounded">
            <p className="font-bold">✅ {result.message}</p>
            <p className="text-sm mt-2">商品數量：{result.productsCount}</p>
            <p className="text-sm">下一步：{result.nextStep}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={!file || uploading}
          className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {uploading ? '上傳中...' : '上傳 Excel'}
        </button>
      </form>

      <div className="mt-8 p-4 bg-gray-50 rounded">
        <h2 className="font-bold mb-2">📋 Excel 格式範例</h2>
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2 text-left">SKU</th>
              <th className="border p-2 text-left">名稱</th>
              <th className="border p-2 text-left">顏色</th>
              <th className="border p-2 text-left">尺寸</th>
              <th className="border p-2 text-left">說明</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border p-2">1133163</td>
              <td className="border p-2">GALENA PACK 30</td>
              <td className="border p-2">黑色</td>
              <td className="border p-2">30L</td>
              <td className="border p-2">專業登山背包</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
```

### 4.2 `src/app/admin/translation-status/page.tsx`（簡化版）

```typescript
'use client';

import { useEffect, useState } from 'react';

export default function TranslationStatusPage() {
  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/translation-status')
      .then(r => r.json())
      .then(data => {
        setStatus(data);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="p-8 text-center">載入中...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">翻譯進度</h1>

      {/* 大型通知 */}
      <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded mb-6">
        <h2 className="font-bold text-lg text-amber-900">⏳ 暫停中</h2>
        <p className="text-amber-800 mt-2">
          翻譯功能將在 <strong>2024 年 6 月</strong> 啟動
        </p>
        <p className="text-amber-800 mt-2">
          當前狀態：等待商品資料確認
        </p>
      </div>

      {/* 統計卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-4 rounded shadow">
          <div className="text-2xl font-bold">{status?.stats?.totalProducts || 0}</div>
          <div className="text-sm text-gray-600">總商品數</div>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <div className="text-2xl font-bold text-green-600">0</div>
          <div className="text-sm text-gray-600">已翻譯</div>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <div className="text-2xl font-bold text-amber-600">{status?.stats?.pendingProducts || 0}</div>
          <div className="text-sm text-gray-600">待翻譯</div>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <div className="text-2xl font-bold">0%</div>
          <div className="text-sm text-gray-600">完成率</div>
        </div>
      </div>

      {/* 時間軸 */}
      <div className="bg-white p-6 rounded shadow">
        <h2 className="font-bold mb-4">📅 計畫時間表</h2>
        <div className="space-y-3">
          <div className="flex gap-4">
            <div className="text-sm font-bold w-20">✅ 5 月中</div>
            <div className="text-sm">架構改版完成</div>
          </div>
          <div className="flex gap-4">
            <div className="text-sm font-bold w-20">📊 6 月初</div>
            <div className="text-sm">收到商品資料</div>
          </div>
          <div className="flex gap-4">
            <div className="text-sm font-bold w-20">🔄 6 月中</div>
            <div className="text-sm">開始大規模翻譯</div>
          </div>
          <div className="flex gap-4">
            <div className="text-sm font-bold w-20">🚀 6 月末</div>
            <div className="text-sm">翻譯完成，上線</div>
          </div>
        </div>
      </div>

      {/* 目前的消息 */}
      <div className="mt-8 bg-blue-50 p-4 rounded">
        <p className="text-sm text-blue-800">
          <strong>💡 提示：</strong>
          目前網站已準備好接收商品資料，
          只需在 6 月上傳 Excel，系統會自動進行翻譯和圖片爬蟲。
          無需現在做任何操作。
        </p>
      </div>
    </div>
  );
}
```

### 4.3 `src/app/admin/version-history/page.tsx`

```typescript
'use client';

import { useEffect, useState } from 'react';

export default function VersionHistoryPage() {
  const [history, setHistory] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/version-history')
      .then(r => r.json())
      .then(data => {
        setHistory(data);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="p-8 text-center">載入中...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">版本歷史</h1>

      {history?.message && (
        <div className="bg-blue-50 p-4 rounded mb-6">
          <p className="text-blue-800">ℹ️ {history.message}</p>
        </div>
      )}

      {history?.versions && history.versions.length > 0 ? (
        <div className="space-y-4">
          {history.versions.map((version: any, index: number) => (
            <div key={index} className="border rounded p-4">
              <h3 className="font-bold">{version.version}</h3>
              <p className="text-sm text-gray-600">{version.createdAt}</p>
              <p className="text-sm mt-2">{version.description}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-600">尚無版本歷史</p>
          <p className="text-sm text-gray-500 mt-2">
            版本歷史將在 6 月翻譯開始時自動生成
          </p>
        </div>
      )}

      <div className="mt-8 p-4 bg-gray-50 rounded">
        <p className="text-sm text-gray-700">
          <strong>📝 說明：</strong>
          版本管理系統已準備就緒，
          將在 6 月開始翻譯時自動記錄每個版本的變更。
        </p>
      </div>
    </div>
  );
}
```

### 4.4 `src/app/admin/dashboard/page.tsx`

```typescript
'use client';

import Link from 'next/link';

export default function AdminDashboard() {
  return (
    <div className="max-w-6xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-2">管理儀表板</h1>
      <p className="text-gray-600 mb-8">5 月架構改版版本</p>

      {/* 狀態卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="font-bold text-lg mb-2">📤 上傳商品</h3>
          <p className="text-sm text-gray-600 mb-4">上傳 Excel 商品清單</p>
          <Link href="/admin/upload" className="text-blue-600 hover:underline">
            前往上傳 →
          </Link>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="font-bold text-lg mb-2">🔄 翻譯進度</h3>
          <p className="text-sm text-gray-600 mb-4">查看翻譯狀態（6 月啟動）</p>
          <Link href="/admin/translation-status" className="text-blue-600 hover:underline">
            查看進度 →
          </Link>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="font-bold text-lg mb-2">📋 版本歷史</h3>
          <p className="text-sm text-gray-600 mb-4">查看版本變更記錄</p>
          <Link href="/admin/version-history" className="text-blue-600 hover:underline">
            查看歷史 →
          </Link>
        </div>
      </div>

      {/* 重要通知 */}
      <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded mb-8">
        <h2 className="font-bold text-amber-900 mb-2">⏳ 目前狀態：5 月架構改版</h2>
        <ul className="text-sm text-amber-800 space-y-2">
          <li>✅ 網站架構已改版完成</li>
          <li>✅ 支持 Excel 商品上傳</li>
          <li>✅ 圖片爬蟲功能保留（原有）</li>
          <li>⏸️ 翻譯功能暫停（等 6 月）</li>
          <li>⏸️ 版本管理框架就位（預留）</li>
        </ul>
      </div>

      {/* 計畫時間表 */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="font-bold text-lg mb-4">📅 計畫時間表</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-green-600">✅ 5 月中旬</h3>
            <p className="text-sm text-gray-600">架構改版完成，支持 Excel 上傳</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-600">📊 6 月初</h3>
            <p className="text-sm text-gray-600">收到正式商品資料（1000+ 商品）</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-600">🔄 6 月中旬</h3>
            <p className="text-sm text-gray-600">開始大規模翻譯（Gemini API）</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-600">🚀 6 月末</h3>
            <p className="text-sm text-gray-600">翻譯完成，生成報告並上線</p>
          </div>
        </div>
      </div>

      {/* 當前可做的事 */}
      <div className="mt-8 bg-blue-50 p-6 rounded-lg">
        <h2 className="font-bold text-blue-900 mb-4">💡 目前你可以做的事</h2>
        <ul className="text-sm text-blue-800 space-y-2">
          <li>1. 準備商品 Excel（型號、顏色、尺寸、基本說明）</li>
          <li>2. 上傳 Excel 測試系統（使用「上傳商品」頁面）</li>
          <li>3. 確認圖片爬蟲功能（原有功能保留）</li>
          <li>4. 等待 6 月商品資料確認</li>
        </ul>
      </div>

      {/* 6 月的計畫 */}
      <div className="mt-8 bg-purple-50 p-6 rounded-lg">
        <h2 className="font-bold text-purple-900 mb-4">🚀 6 月將自動進行</h2>
        <ul className="text-sm text-purple-800 space-y-2">
          <li>✅ 自動爬蟲英文官網說明</li>
          <li>✅ Gemini API 翻譯為繁體中文</li>
          <li>✅ 對比台灣官網既有翻譯</li>
          <li>✅ Checkpoint 增量保存（每 50 個）</li>
          <li>✅ 自動版本控制和備份</li>
          <li>✅ 生成 3 份 Excel 報告</li>
          <li>✅ 自動部署到 Vercel</li>
        </ul>
      </div>
    </div>
  );
}
```

---

## 第 5 步：路由配置

### 5.1 `src/app/admin/layout.tsx`

```typescript
import Link from 'next/link';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen">
      {/* 側邊欄 */}
      <nav className="w-64 bg-gray-900 text-white p-6">
        <h1 className="text-xl font-bold mb-6">Montbell 管理中心</h1>
        <ul className="space-y-2">
          <li>
            <Link href="/admin/dashboard" className="hover:bg-gray-800 p-2 block rounded">
              儀表板
            </Link>
          </li>
          <li>
            <Link href="/admin/upload" className="hover:bg-gray-800 p-2 block rounded">
              上傳商品
            </Link>
          </li>
          <li>
            <Link href="/admin/translation-status" className="hover:bg-gray-800 p-2 block rounded">
              翻譯進度
            </Link>
          </li>
          <li>
            <Link href="/admin/version-history" className="hover:bg-gray-800 p-2 block rounded">
              版本歷史
            </Link>
          </li>
        </ul>

        {/* 狀態提示 */}
        <div className="mt-8 p-4 bg-amber-900 rounded text-sm">
          <p className="font-bold">⏳ 狀態：5 月改版中</p>
          <p className="mt-2 text-xs">翻譯功能 6 月啟動</p>
        </div>
      </nav>

      {/* 主要內容 */}
      <main className="flex-1 bg-gray-50">
        {children}
      </main>
    </div>
  );
}
```

---

## 第 6 步：預留檔案結構（未來 6 月使用）

### 6.1 `lib/checkpointManager.ts`（預留，暫無功能）

```typescript
/**
 * Checkpoint 管理器
 * 
 * ⏸️ 目前暫不實作
 * 等 6 月翻譯開始時再啟用
 * 
 * 功能：
 * - 每 50 個商品自動保存 checkpoint
 * - 支持中途恢復
 * - 自動合併 checkpoint
 */

export class CheckpointManager {
  private checkpointDir = 'data/scraping_checkpoints';
  private checkpointInterval = 50;

  async saveCheckpoint(
    checkpointIndex: number,
    products: any[],
    startIndex: number,
    endIndex: number
  ): Promise<void> {
    // TODO: 6 月實作
    console.log('[預留] Checkpoint 保存功能等待 6 月啟用');
  }

  async mergeAllCheckpoints(): Promise<any[]> {
    // TODO: 6 月實作
    console.log('[預留] Checkpoint 合併功能等待 6 月啟用');
    return [];
  }
}
```

### 6.2 `lib/versionControlManager.ts`（預留）

```typescript
/**
 * 版本控制管理器
 * 
 * ⏸️ 目前暫不實作
 * 等 6 月翻譯開始時再啟用
 * 
 * 功能：
 * - 版本號自動遞增
 * - 自動備份舊版本
 * - 支持版本回滾
 * - 版本歷史記錄
 */

export class VersionControlManager {
  async createNewVersion(
    newData: any,
    changeDescription: string,
    changeStats: any
  ): Promise<string> {
    // TODO: 6 月實作
    console.log('[預留] 版本控制功能等待 6 月啟用');
    return '1.0.0';
  }

  async rollbackToVersion(version: string): Promise<void> {
    // TODO: 6 月實作
    console.log('[預留] 版本回滾功能等待 6 月啟用');
  }
}
```

### 6.3 `lib/translationStatusManager.ts`（預留）

```typescript
/**
 * 翻譯狀態管理器
 * 
 * ⏸️ 目前暫不實作
 * 等 6 月翻譯開始時再啟用
 * 
 * 功能：
 * - 追蹤翻譯進度
 * - 統計完成率
 * - 分類統計
 * - 生成狀態報告
 */

export class TranslationStatusManager {
  async updateTranslationMeta(
    products: any[],
    translations: Map<string, string>,
    version: string,
    operator: string,
    description: string
  ): Promise<void> {
    // TODO: 6 月實作
    console.log('[預留] 翻譯狀態更新功能等待 6 月啟用');
  }

  async generateTranslationStatus(): Promise<void> {
    // TODO: 6 月實作
    console.log('[預留] 翻譯狀態生成功能等待 6 月啟用');
  }
}
```

---

## 第 7 步：更新 `package.json`

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "translate:montbell-tw": "echo '等待 6 月實作...'",
    "sync:images": "node scripts/sync-images.js",
    "cleanup:checkpoints": "echo '等待 6 月實作...'"
  },
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "xlsx": "^0.18.5"
  }
}
```

---

## ✅ 實作檢查清單

### 第 1 步：目錄結構（1 小時）
- [ ] 建立 `data/` 目錄
- [ ] 建立 `data/scraping_checkpoints/`
- [ ] 建立 `data/backups/`
- [ ] 建立 `data/scraping_logs/`
- [ ] 更新 `.gitignore`
- [ ] git add + commit + push

### 第 2 步：預留資料（30 分鐘）
- [ ] 建立 `public/translationMeta.json`
- [ ] 建立 `public/translationStatus.json`
- [ ] 建立 `public/versionHistory.json`
- [ ] 建立 `public/robots.txt`

### 第 3 步：API 端點（2-3 小時）
- [ ] `src/app/api/upload-excel/route.ts`
- [ ] `src/app/api/translation-status/route.ts`
- [ ] `src/app/api/version-history/route.ts`

### 第 4 步：管理頁面（3-4 小時）
- [ ] `src/app/admin/upload/page.tsx`
- [ ] `src/app/admin/translation-status/page.tsx`
- [ ] `src/app/admin/version-history/page.tsx`
- [ ] `src/app/admin/dashboard/page.tsx`
- [ ] `src/app/admin/layout.tsx`

### 第 5 步：預留檔案（15 分鐘）
- [ ] `lib/checkpointManager.ts`
- [ ] `lib/versionControlManager.ts`
- [ ] `lib/translationStatusManager.ts`

### 第 6 步：更新 package.json（5 分鐘）
- [ ] 新增 script 項目
- [ ] npm install xlsx

### 第 7 步：測試部署（1-2 小時）
- [ ] 本地測試所有頁面
- [ ] 測試 Excel 上傳
- [ ] 測試 API 端點
- [ ] git push
- [ ] Vercel 自動部署
- [ ] 確認上線

---

## 🎯 完成後的狀態

### 網站將擁有

```
✅ Excel 上傳功能
✅ 商品資料管理
✅ 圖片爬蟲功能（原有保留）
✅ 管理儀表板
✅ 版本控制框架（預留）
✅ Checkpoint 機制（預留）
✅ 三層備份架構（預留）

⏸️ 翻譯功能（等 6 月啟用）
⏸️ 自動翻譯流程（等 6 月啟用）
⏸️ Excel 導出（等 6 月啟用）
```

### 成本與時間

```
開發時間：7-10 小時
API 消耗：$0（無翻譯）
Token 消耗：$0（無翻譯）
人力成本：最小化（預留結構）

6 月只需：
1. 上傳商品 Excel
2. 點擊「開始翻譯」按鈕
3. 等待自動完成
```

---

**現在準備開始實作了嗎？** ✅
