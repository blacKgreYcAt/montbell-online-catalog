# Montbell Taiwan 線上目錄專案 - 完整進度記錄

**專案名稱**：Montbell Taiwan 線上目錄改版
**狀態**：架構設計完成，待架構實作
**翻譯部分**：暫緩至 2024 年 6 月
**最後更新**：2024 年 5 月

---

## 📋 專案概述

### 核心目標
```
1️⃣ 改版現有網站架構
   ✅ 支持 Excel 商品上傳
   ✅ 自動爬蟲官網圖片（CDN 外連）
   ✅ 支持版本管理和進度追蹤
   ❌ 暫不進行翻譯（等 6 月）

2️⃣ 為未來翻譯做準備
   ✅ 預留翻譯資料結構
   ✅ 預留 checkpoint 機制
   ✅ 預留版本控制系統
```

### 時間安排
```
現在（5 月）：架構改版 + 爬蟲功能
6 月初：收到商品資料
6 月中：執行大規模翻譯 + 版本管理
```

---

## ✅ 已完成的工作

### 第一階段：需求分析與方案設計

#### 已生成的文檔

| 文檔名 | 內容 | 頁數 | 狀態 |
|--------|------|------|------|
| ONLINE_CATALOG_PROJECT.md | 完整的線上目錄架構設計 | 80KB | ✅ 完成 |
| FEATURE_EVALUATION.md | Gemini 翻譯和 Excel 匯出評估 | 50KB | ✅ 完成 |
| PLAN_B_ENHANCED.md | 方案 B 增強版（版本管理+進度追蹤） | 70KB | ✅ 完成 |
| IMAGE_ARCHITECTURE_ANALYSIS.md | 圖片直連官網 vs Google Drive 分析 | 40KB | ✅ 完成 |
| MONTBELL_TW_ACTUAL_ANALYSIS.md | 實際官網結構分析（Chrome MCP） | 60KB | ✅ 完成 |
| COMPLETE_WORKFLOW_WITH_SAFEGUARDS.md | 完整流程 + 三層保護機制 | 100KB | ✅ 完成 |
| CHECKPOINT_STORAGE_STRATEGY.md | Checkpoint 存儲策略 | 80KB | ✅ 完成 |

**總計**：約 480KB 的完整設計文檔

### 第二階段：核心決策確認

#### 已確認的選擇

```
✅ 圖片來源：保持直連品牌官網（無改動）
✅ 翻譯方案：方案 B 增強版（版本管理+進度追蹤）
✅ 架構方案：混合式（public/ + data/ 目錄）
✅ 備份策略：三重備份（本地 + GitHub + Vercel）
✅ Checkpoint 位置：data/scraping_checkpoints/
✅ 翻譯延期：暫緩至 6 月，先做架構
```

---

## 🔧 第二階段：架構改版方案（現在進行）

### 改版內容（只包含架構，不含翻譯邏輯）

#### Part 1：新增目錄結構

```
online-catalog/
├─ public/
│  ├─ products.json
│  ├─ imageMapping.json
│  ├─ translationMeta.json              ← 新增（預留結構）
│  ├─ translationStatus.json            ← 新增（預留結構）
│  ├─ versionHistory.json               ← 新增（預留結構）
│  └─ robots.txt                        ← 新增（安全）
│
├─ data/                                 ← 新增目錄
│  ├─ scraping_checkpoints/             ← Checkpoint 儲存位置
│  ├─ backups/                          ← 版本備份
│  ├─ scraping_logs/                    ← 執行日誌
│  └─ temp/                             ← 臨時檔案
│
├─ src/
│  ├─ app/
│  ├─ components/
│  ├─ lib/
│  │  ├─ translationStatusManager.ts    ← 新增
│  │  ├─ versionControlManager.ts       ← 新增
│  │  ├─ checkpointManager.ts           ← 新增
│  │  ├─ processingMonitor.ts           ← 新增
│  │  └─ ... (保持原有代碼)
│  └─ ...
│
├─ scripts/
│  ├─ excel-to-json.js                  ← 新增（Excel 上傳處理）
│  ├─ sync-images.js                    ← 保留（圖片爬蟲）
│  └─ cleanup-checkpoints.js            ← 新增（清理舊檔案）
│
└─ .gitignore                           ← 更新（允許 data/ 被追蹤）
```

#### Part 2：新增 API 端點（暫無翻譯邏輯）

```
POST /api/upload-excel
  功能：上傳商品 Excel
  輸入：Excel 檔案
  輸出：
    {
      success: true,
      productsCount: 1000,
      status: "awaiting_image_sync"
    }

POST /api/sync-images
  功能：爬蟲官網圖片
  輸入：products.json
  輸出：imageMapping.json
  狀態：✅ 已有（保留原有）

GET /api/translation-status
  功能：查看翻譯進度
  輸出：
    {
      totalProducts: 1000,
      translatedProducts: 0,
      completionRate: 0,
      message: "等待 6 月翻譯"
    }

GET /api/version-history
  功能：查看版本歷史
  輸出：版本列表
  狀態：✅ 預留結構

GET /api/download-excel
  功能：下載中英文對照表
  狀態：❌ 先跳過（6 月再做）
```

#### Part 3：管理頁面（簡化版，無翻譯進度）

```
src/app/admin/upload/page.tsx           ← 新增
  功能：上傳 Excel 商品清單
  
src/app/admin/translation-status/page.tsx ← 新增（簡化版）
  功能：顯示翻譯狀態（目前都是 0）
  備註：等 6 月才會有數據

src/app/admin/version-history/page.tsx  ← 新增
  功能：查看版本歷史
  
src/app/admin/dashboard/page.tsx         ← 新增
  功能：總覽儀表板
```

---

## 📝 待實作的清單

### 現在（5 月）要做的事 ✅

#### 1️⃣ 目錄結構（1 小時）
- [ ] 建立 `data/scraping_checkpoints/`
- [ ] 建立 `data/backups/`
- [ ] 建立 `data/scraping_logs/`
- [ ] 建立 `data/temp/`

#### 2️⃣ 更新 `.gitignore`（15 分鐘）
- [ ] 確保 `data/` 被 Git 追蹤
- [ ] 忽略 `data/temp/`

#### 3️⃣ 新增資料結構檔案（30 分鐘）
- [ ] `public/translationMeta.json`（預留，內容為空）
- [ ] `public/translationStatus.json`（預留，內容為空）
- [ ] `public/versionHistory.json`（預留，內容為空）

#### 4️⃣ 新增 API 端點（2-3 小時）
- [ ] `POST /api/upload-excel` - Excel 上傳
- [ ] `GET /api/translation-status` - 進度查詢（目前固定回應）
- [ ] `GET /api/version-history` - 版本歷史
- [ ] `GET /api/download-excel` - Excel 下載（預留，先不做）

#### 5️⃣ 新增管理頁面（3-4 小時）
- [ ] `src/app/admin/upload/page.tsx` - 上傳頁面
- [ ] `src/app/admin/translation-status/page.tsx` - 進度頁面（簡化版）
- [ ] `src/app/admin/version-history/page.tsx` - 版本頁面
- [ ] `src/app/admin/dashboard/page.tsx` - 儀表板

#### 6️⃣ 新增管理工具（1-2 小時）
- [ ] `lib/checkpointManager.ts`（預留，無需功能）
- [ ] `lib/versionControlManager.ts`（預留，無需功能）
- [ ] `lib/translationStatusManager.ts`（預留，無需功能）

**現階段總時間**：7-10 小時

### 6 月才做的事 ⏸️

```
❌ 不要做翻譯邏輯
❌ 不要做 Gemini API 整合
❌ 不要做官網爬蟲（英文版本）
❌ 不要做翻譯驗證

等收到商品資料後再做：
✅ 翻譯邏輯實作
✅ Checkpoint 自動保存
✅ 批量翻譯流程
✅ 版本管理自動化
✅ Excel 導出功能
```

---

## 🎯 架構改版的目標

### 現在完成後的狀態

```
✅ 網站支持 Excel 商品上傳
✅ 圖片爬蟲功能正常（保留原有）
✅ 版本管理框架就位（預留）
✅ Checkpoint 機制就位（預留）
✅ 管理頁面完成（簡化版）

⏸️ 翻譯部分完全跳過
⏸️ 無 API 消耗（節省成本）
⏸️ 等 6 月再動
```

### 6 月接上翻譯時

```
1. 上傳正式商品 Excel
2. 系統自動：
   ✅ 解析 Excel
   ✅ 爬蟲官網圖片
   ✅ 保存 checkpoint（每 50 個）
   ✅ 調用 Gemini 翻譯
   ✅ 對比台灣官網
   ✅ 自動版本控制
   ✅ 生成 3 份 Excel

無縫接上，無需改代碼！
```

---

## 💾 所有文檔清單

### 設計文檔（已完成，可參考）

```
1. ONLINE_CATALOG_PROJECT.md
   - 完整的線上目錄專案架構
   - 10 個完整代碼範例
   - 包含爬蟲、翻譯、版本管理

2. FEATURE_EVALUATION.md
   - 翻譯功能可行性評估
   - Excel 匯出評估
   - 四個方案對比

3. PLAN_B_ENHANCED.md
   - 推薦的增強方案
   - 版本管理系統
   - 進度追蹤頁面代碼

4. IMAGE_ARCHITECTURE_ANALYSIS.md
   - 圖片直連 vs Google Drive
   - 為什麼保留官網直連
   - 與翻譯系統整合

5. MONTBELL_TW_ACTUAL_ANALYSIS.md
   - 實際官網結構分析（用 Chrome MCP 掃描）
   - 精確的爬蟲配置
   - Montbell 特用翻譯規則

6. COMPLETE_WORKFLOW_WITH_SAFEGUARDS.md
   - 完整的四步流程確認
   - 三層保護機制
   - 風險評估

7. CHECKPOINT_STORAGE_STRATEGY.md
   - Checkpoint 存儲策略
   - data/ vs public/ 選擇
   - 三重備份方案
```

### 實作文檔（待完成）

```
待生成（現在做）：
- ARCHITECTURE_MIGRATION_GUIDE.md
  （如何從舊架構遷移到新架構）

- API_ENDPOINTS_SPEC.md
  （新增 API 的完整規格）

- ADMIN_PAGES_IMPLEMENTATION.md
  （管理頁面的實作指南）

- EXCEL_UPLOAD_HANDLER.md
  （Excel 上傳和解析的實作）

待生成（6 月做）：
- TRANSLATION_INTEGRATION_GUIDE.md
  （翻譯邏輯的整合指南）

- GEMINI_BATCH_PROCESSING.md
  （批量翻譯流程）

- PRODUCTION_DEPLOYMENT.md
  （正式上線部署指南）
```

---

## 📅 時間規劃

### 2024 年 5 月（現在）

```
第 1 週：架構設計（已完成）✅
第 2-3 週：架構實作（現在進行）⏳
  ├─ 目錄結構
  ├─ API 端點
  ├─ 管理頁面
  └─ 工具函數

第 4 週：測試 + 優化
  ├─ 功能測試
  ├─ 性能測試
  ├─ 安全審核
  └─ 上線準備
```

### 2024 年 6 月

```
第 1 週：收到商品資料 📊
第 2-4 週：翻譯實作
  ├─ 整合 Gemini API
  ├─ Checkpoint 機制
  ├─ 版本管理自動化
  ├─ 大規模翻譯執行
  └─ 生成報告

第 5 週：最終上線
```

---

## 💡 關鍵決策記錄

### 決策 1️⃣：翻譯延期

```
✅ 決定：延期到 6 月
原因：
  - 商品資料未到
  - 節省 Gemini API 成本
  - 避免重複翻譯

影響：
  - 現在只做架構
  - 6 月無縫接翻譯
  - 零浪費
```

### 決策 2️⃣：圖片來源

```
✅ 決定：保留官網直連（無改動）
原因：
  - 已正常運行
  - 無需複雜爬蟲
  - 官網自動更新

影響：
  - 簡化實作
  - 降低維護成本
  - 減少改動風險
```

### 決策 3️⃣：Checkpoint 位置

```
✅ 決定：data/ 目錄（非 public/）
原因：
  - 更安全（不暴露檔案）
  - 符合生產標準
  - 易於管理

影響：
  - 需要額外目錄結構
  - 三重備份（本地 + GitHub + Vercel）
  - 無空間壓力（6.5MB 很小）
```

### 決策 4️⃣：備份策略

```
✅ 決定：三重備份
  備份 1️⃣：本地 data/ 目錄
  備份 2️⃣：GitHub 遠端倉庫
  備份 3️⃣：Vercel 伺服器

優點：
  - 任何一個壞了都能恢復
  - 企業級可靠性
  - 無損失風險
```

---

## 🔗 文檔之間的關係

```
需求分析
  ↓
ONLINE_CATALOG_PROJECT.md ← 完整架構設計
  ↓
PLAN_B_ENHANCED.md ← 推薦的版本管理方案
  ↓
MONTBELL_TW_ACTUAL_ANALYSIS.md ← 實際官網結構
COMPLETE_WORKFLOW_WITH_SAFEGUARDS.md ← 完整流程 + 保護機制
  ↓
CHECKPOINT_STORAGE_STRATEGY.md ← Checkpoint 位置決策
  ↓
IMAGE_ARCHITECTURE_ANALYSIS.md ← 圖片來源決策
  ↓
現在：架構實作（只包含上述設計，無翻譯）
  ↓
6 月：翻譯實作（使用相同架構）
```

---

## ✅ 現在的行動方案

### 你需要做什麼

```
1. 確認這份記錄
   - 檢查所有決策
   - 檢查時間規劃
   - 檢查待實作清單

2. 準備開發環境
   - git 確認 data/ 目錄結構
   - .gitignore 更新
   - 本地測試環境

3. 開始架構實作
   - 按照「待實作清單」順序進行
   - 先做目錄結構（1 小時）
   - 再做 API 端點（2-3 小時）
   - 最後做管理頁面（3-4 小時）
```

### 我提供什麼

```
✅ 完整的設計文檔（已有）
✅ 精確的代碼框架（待生成）
✅ 逐步的實作指南（待生成）
✅ 測試用例（待生成）
✅ 部署檢查清單（待生成）
```

---

## 📞 確認無誤

### 這份記錄是否完整？

- [ ] 所有決策都有記錄
- [ ] 時間規劃清晰
- [ ] 待實作清單完整
- [ ] 文檔清單完整

### 5 月的計劃是否清楚？

- [ ] 只做架構，不做翻譯
- [ ] 預留翻譯結構
- [ ] 準備 6 月無縫接翻譯
- [ ] 節省成本和 TOKEN

### 你是否同意延期翻譯？

- [ ] 同意延期到 6 月
- [ ] 現在只做架構
- [ ] 準備好收 6 月的資料

---

**一切準備就緒？我現在可以開始生成架構實作代碼了！** ✅
